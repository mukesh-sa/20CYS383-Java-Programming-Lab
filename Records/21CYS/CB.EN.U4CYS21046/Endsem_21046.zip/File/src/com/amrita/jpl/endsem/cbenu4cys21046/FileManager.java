package com.amrita.jpl.endsem.cbenu4cys21046;

import java.util.List;

public interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void displayAllFiles();
    List<File> getAllFiles();
    void saveToFile(String fileName);
    void loadFromFile(String fileName);
}

