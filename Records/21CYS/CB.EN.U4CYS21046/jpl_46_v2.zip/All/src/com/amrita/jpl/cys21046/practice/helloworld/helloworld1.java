/**
 * The HelloWorld class prints a simple "Hello World!" message.
 */
public class helloworld1 {

    /**
     * The main method is the entry point of the program.
     * It prints the "Hello World!" message to the console.
     *
     * @param args The command-line arguments passed to the program (unused in this case)
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
